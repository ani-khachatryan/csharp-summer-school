int main()
{
    while(true) {
        sleep(1000);
    }
}